package com.blackflower.curriculumcreator.customComponents;

/**
 *
 * @author emirs
 */
public class CCRoundedButton {
    
}
