package com.blackflower.curriculumcreator.customComponents;

/**
 *
 * @author emirs
 */
public interface EventSwitchSelected {

    public void onSelected(boolean selected);
}
