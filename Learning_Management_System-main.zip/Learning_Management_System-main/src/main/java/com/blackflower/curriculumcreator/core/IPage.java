package com.blackflower.curriculumcreator.core;

/**
 *
 * @author emirs
 */
public interface IPage {
    public void onPageSetted(); 
}
