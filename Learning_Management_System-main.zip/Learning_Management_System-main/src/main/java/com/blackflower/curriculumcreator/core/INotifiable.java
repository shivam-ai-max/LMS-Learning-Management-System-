package com.blackflower.curriculumcreator.core;

/**
 *
 * @author emirs
 */
public interface INotifiable {
    public String getNotificationContent();
    
}
